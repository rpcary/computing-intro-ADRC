#!/bin/bash 
#This script expects at least one argument after the program.

echo "number of arguments: $#"
echo "name of program    : $0"
echo "first argument     : $1"
echo "all arguments      : $@"

exit 0
